package com.controller.site;

import com.dao.ProductDao;
import com.entiry.Product;
import com.util.Func;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

//@WebServlet(name = "Home", value = "/*", loadOnStartup = 10)
public class HomeController extends HttpServlet {
    private ProductDao productDao;

    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getRequestURI();
        if (path.matches("/product/[\\w]*")) {
            showProductDetail(req, resp);
        }
        req.getRequestDispatcher("/view/index.jsp").forward(req, resp);
    }

    public void showProductDetail(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = Func.getLastPath(req.getRequestURI());
        Product p = productDao.findById(Long.valueOf(id));
        req.setAttribute("product", p);

        req.getRequestDispatcher("/view/ProductDetail.jsp").forward(req, resp);
    }

}
