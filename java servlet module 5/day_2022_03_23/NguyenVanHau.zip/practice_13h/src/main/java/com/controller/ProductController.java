package com.controller;

import com.dao.ProductDao;
import com.entiry.Product;
import com.util.Func;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ProductManagement", value = {"/products", "/products/new", "/products/update", "/products/delete", "/products/search"})
public class ProductController extends HttpServlet {
    private ProductDao productDao;

    @Override
    public void init() throws ServletException {
        super.init();
        System.out.println("Hello world");
        productDao = new ProductDao();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        switch (Func.getLastPath(req.getRequestURI())) {
            case "products":
                req.setAttribute("listProduct", productDao.findAll());
                req.getRequestDispatcher("/view/ProductManagement.jsp").forward(req, resp);
                break;
            case "new":
                req.getRequestDispatcher("/view/AddProduct.jsp").forward(req, resp);
                break;
            case "update":
                req.setAttribute("productUpdate", productDao.findById(Long.valueOf(req.getParameter("id"))));
                req.getRequestDispatcher("/view/UpdateProduct.jsp").forward(req, resp);
                break;
            case "search":
                String q = req.getParameter("q");
                System.out.println("search->" + q);

                List<Product> listSearch = productDao.searchByName(q.trim());
                req.setAttribute("listProduct", listSearch);
                req.getRequestDispatcher("/view/ProductManagement.jsp").forward(req, resp);
                break;
            default:
                break;
        }
    }

    protected void addNewProduct(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("post new");

        req.setAttribute("type", "error");
        boolean check = false;

        Product p = new Product();
        p.setName(req.getParameter("name"));
        p.setPrice(Double.valueOf(req.getParameter("price")));
        if (productDao.save(p) != null)
            check = true;

        if (check) {
            req.setAttribute("type", "success");
            req.setAttribute("message", "Add successfully!");
        } else
            req.setAttribute("message", "Add failed!");
        req.getRequestDispatcher("/view/AddProduct.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        switch (Func.getLastPath(req.getRequestURI())) {
            case "new":
                addNewProduct(req, resp);
                break;
            case "update":
                updateProduct(req, resp);
                break;
            case "delete":
                deleteProduct(req, resp);
                break;
            default:
                break;
        }
    }

    public void updateProduct(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("post update");
        String id = req.getParameter("id");


        req.setAttribute("type", "error");
        boolean check = false;

        System.out.println("id=>>>" + id);

        Product p = new Product();
        p.setId(Long.valueOf(id));
        p.setName(req.getParameter("name"));
        p.setPrice(Double.valueOf(req.getParameter("price")));
        if (productDao.update(p) != null)
            check = true;

        if (check) {
            req.setAttribute("productUpdate", p);
            req.setAttribute("type", "success");
            req.setAttribute("message", "Update successfully!");
        } else
            req.setAttribute("message", "Update failed!");

        req.getRequestDispatcher("/view/UpdateProduct.jsp").forward(req, resp);
    }

    public void deleteProduct(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String[] url = req.getRequestURI().split("/");
        String path = url[url.length - 1];

        String id = req.getParameter("id");
        req.setAttribute("type", "error");
        if (id.matches("[0-9]*")) {
            productDao.deleteById(Long.valueOf(id));
            req.setAttribute("listProduct", productDao.findAll());
            req.setAttribute("type", "success");
            req.setAttribute("message", "Delete successfully!");
        } else
            req.setAttribute("message", "Delete failed!");
        req.getRequestDispatcher("/view/ProductManagement.jsp").forward(req, resp);
    }

}
