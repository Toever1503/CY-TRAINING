package com.demovm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoVmApplicationTests {

    @Test
    void contextLoads() {
    }

}
