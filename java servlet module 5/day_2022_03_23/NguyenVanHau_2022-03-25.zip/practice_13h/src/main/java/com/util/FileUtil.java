package com.util;

public class FileUtil {
    public static String uploadImage(){
        return "";
    }
}
