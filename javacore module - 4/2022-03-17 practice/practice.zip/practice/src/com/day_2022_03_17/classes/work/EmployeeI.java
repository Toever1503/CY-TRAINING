package com.day_2022_03_17.classes.work;

public interface EmployeeI {
    String name = null;
    void hello();
}
