package com.day_2022_03_17.day_2022_03_17.classes;

import java.util.Scanner;

public interface IACTION {
    void enterInformation(Scanner scan);
    StringBuilder displayInformation();
}
