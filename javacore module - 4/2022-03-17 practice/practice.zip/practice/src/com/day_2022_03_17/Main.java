package com.day_2022_03_17;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
    }

    public void testOddEven(){
        int number1;
        int number2;
        Scanner input = new Scanner(System.in);

        System.out.println("Enter number 1: ");
        System.out.println("Enter number 2: ");
    }

}
