package com.service;

import com.entity.dto.CategoryDto;
import com.entity.model.CategoryModel;

public interface CategoryService extends BaseService<CategoryModel, CategoryDto, Long> {

}
