package com.example.practice_2022_04_08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practice20220408Application {

    public static void main(String[] args) {
        SpringApplication.run(Practice20220408Application.class, args);
    }

}
