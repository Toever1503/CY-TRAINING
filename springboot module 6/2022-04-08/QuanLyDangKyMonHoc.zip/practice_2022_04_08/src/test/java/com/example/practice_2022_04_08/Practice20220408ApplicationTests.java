package com.example.practice_2022_04_08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practice20220408ApplicationTests {

    @Test
    void contextLoads() {
    }

}
